## Backend server in Nodejs

To run this server, replace the MONGO_URL environment variable with your personal website and run npm run dev

